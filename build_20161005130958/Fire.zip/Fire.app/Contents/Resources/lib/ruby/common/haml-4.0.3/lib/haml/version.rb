module Haml
  VERSION = "4.0.3"
end
